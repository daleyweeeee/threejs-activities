import * as THREE from 'three'

// Scene
const scene = new THREE.Scene()

const group = new THREE.Group()
scene.add(group)

const box1 = new THREE.Mesh(
    new THREE.BoxGeometry(2, 5, 4),
    new THREE.MeshBasicMaterial({ color: 0xff0000 })
)
box1.position.x = -4
group.add(box1)

const box2 = new THREE.Mesh(
    new THREE.BoxGeometry(2, 5, 4),
    new THREE.MeshBasicMaterial({ color: 0xff0000 })
)
box2.position.x = 0
group.add(box2)

const box3 = new THREE.Mesh(
    new THREE.BoxGeometry(2, 5, 4),
    new THREE.MeshBasicMaterial({ color: 0xff0000 })
)
box3.position.x = 4
group.add(box3)

// Sizes
const sizes = {
    width: 800,
    height: 600
}

// Camera
const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height)
camera.position.z = 20
scene.add(camera)

// Renderer
const canvas = document.querySelector('canvas.webcanvas')
const renderer = new THREE.WebGLRenderer({ canvas })
renderer.setSize(sizes.width, sizes.height)
renderer.render(scene, camera)
